class LtPlayer
  def initialize()
    @atk=Random.rand(20)+5
    @def=Random.rand(20)+5
    @x=0
    @y=0
    @hp=100
    @hand=LtKnife.new()
    @bpk=[LtHealthPotion.new()]
  end
  def move(d)
    if d==1 && $map[@x-1][@y] != 4 && $map[@x-1][@y].class != LtEnemy
      @x=@x-1
      blockJudge($map[@x][@y])
    end
    if d==2 && $map[@x+1][@y] != 4 && $map[@x+1][@y].class != LtEnemy
      @x=@x+1
      blockJudge($map[@x][@y])
    end
    if d==3 && $map[@x][@y-1] != 4 && $map[@x][@y-1].class != LtEnemy
      @y=@y-1
      blockJudge($map[@x][@y])
    end    
    if d==4 && $map[@x][@y+1] != 4 && $map[@x][@y+1].class != LtEnemy
      @y=@y+1
      blockJudge($map[@x][@y])
    end
  end
  def des()
    [@atk,@def,@hp]
  end
  def set_pos(x,y)
    @x=x
    @y=y
  end
  def x()
    @x
  end
  def y()
    @y
  end
  def hp()
    @hp
  end
  def hp=(v)
    @hp=v
  end
  def atk()
    @atk
  end
  def atk=(v)
    @atk=v
  end
  def bpk()
    @bpk
  end
  def bpkAdd(v)
    @bpk.push(v)
  end
  def bpkDelete(v)
    if v <= @bpk.length()
      @bpk.delete_at(v-1)
    else
      puts "Item Does Not Exist." 
    end
  end
  def bpkFetch(v)
    if v <= @bpk.length()
      return @bpk[v-1]
    else
      puts "Item Does Not Exist." 
    end
  end
  def hand()
    @hand
  end
  def hand=(v)
    @hand=v
  end
  def def()
    @def
  end
  def atk_c()
    if @hand==0
      return @atk*2
    else
      return (@atk+@hand.atk)*2+Random.rand(3)
    end
  end
end
def blockJudge(blk)
  if blk==5
    puts "You are hurt by the Barrier's Fragment!"
    $player.hp=$player.hp-10
  elsif blk==6
    g=ltBox()
    puts "You Find a "+g+"!"
    $map[$player.x][$player.y]=0
  elsif blk==8
    puts "You Go to the Next Floor."
    mapGene()
    $floor=$floor+1
  end
end
def ltBox()
  q=Random.rand(6)
  if q==1
    a=LtKnife.new()
  elsif q==0
    a=LtSword.new()
  elsif q==2
    a=LtAxe.new()
  elsif q==3
    a=LtHealthPotion.new()
  elsif q==4
    a=LtAtkPotion.new()
  elsif q==5
    a=LtGlassSword.new()
  end
  $player.bpkAdd(a)
  return a.name
end
