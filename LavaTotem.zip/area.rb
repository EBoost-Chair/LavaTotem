$area="Grassy"
class LtArea 
  def areaSpawn()
    list=[0,0,0,3,3,4,4,5,6]
    a=list[Random.rand(9)]
    if a==0
      $area="Forest"
    elsif a==3
      $area="Grassy"
    elsif a==4
      $area="Wetland"
    elsif a==5
      $area="Icyland"
    elsif a==6
      $area="Desert"
    end  
  end
end
$area_m=LtArea.new()
