puts "LavaTotem(alpha) By Wire2Brain<2754887003@qq.com>"
require "./map.rb"
require "./player.rb"
require "./enemy.rb"
require "./area.rb"
require "./items/item.rb"
require "./items/basic_weapons.rb"
require "./items/basic_potions.rb"
$player=LtPlayer.new()
$floor=1
mapGene()
loop do
  $map.each do |i|
    i.each do |j|
      if j.class == LtEnemy 
        if j.mtk==0
          j.act()
        end
      end
    end
  end
  $map.each do |i|
    i.each do |j|
      if j.class == LtEnemy 
        j.re()
      end
    end
  end
  if $player.hp <= 0
    mapRend()
    puts "You Died!Game Over."
    print "Press Any Key to Exit."
    gets()
    exit()
  end
  loop do
    mapRend()
    print ">"
    a=gets()
    if a =~ /^w$/
      $player.move(1)
	  if $map[$player.x-1][$player.y].class == LtEnemy
         puts "You attacks!"
         $map[$player.x-1][$player.y].hp=$map[$player.x-1][$player.y].hp-$player.atk_c()
      end
      break  
    elsif a =~ /^s$/
      $player.move(2) 
      if $map[$player.x+1][$player.y].class == LtEnemy
         puts "You attacks!"
         $map[$player.x+1][$player.y].hp=$map[$player.x+1][$player.y].hp-$player.atk_c()
      end		 
      break
    elsif a =~ /^a$/
      $player.move(3)
	  if $map[$player.x][$player.y-1].class == LtEnemy
        puts "You attacks!"
        $map[$player.x][$player.y-1].hp=$map[$player.x][$player.y-1].hp-$player.atk_c()
	  end
      break
    elsif a =~ /^d$/
      $player.move(4)
      if $map[$player.x][$player.y+1].class == LtEnemy
         puts "You attacks!"
         $map[$player.x][$player.y+1].hp=$map[$player.x][$player.y+1].hp-$player.atk_c()         
      end
	  break
    elsif a =~ /^u/
      a.slice!(0,1)
      tmp=$player.bpkFetch(a.to_i())
      if tmp.class.superclass == LtItem
        if tmp.sign=="potion"
          tmp.use()
          $player.bpkDelete(a.to_i()) 
          puts "You Drink the "+tmp.name+"."
          break
        else
          puts "Unable to Drink this."
        end
      end     
    elsif a =~ /^i$/
      if $player.hand != 0
        $player.bpkAdd($player.hand)
        puts "You Take Off the "+$player.hand.name
        $player.hand=0
      else
        puts "You Have Nothing in Your Hand."
      end
    elsif a =~ /^k$/
      $player.bpk.each_with_index do |i,j|
         j=j+1
         puts j.to_s+" "+i.name
      end
    elsif a =~ /^o/
      a.slice!(0,1)
      if $player.hand == 0
        tmp=$player.bpkFetch(a.to_i)
        if tmp.class.superclass == LtItem
          if tmp.sign == "weapon"
            $player.hand=tmp
            $player.bpkDelete(a.to_i)
            puts "You Equip the "+tmp.name
          else
            puts "Unable to Equip This."
          end
        end       
      else
        puts "You Already Have Something in Your Hand!"
      end
    elsif a =~ /^l$/
      list=$player.des()
      puts "Health: "+list[2].to_s()
      puts "Attack: "+list[0].to_s()
      puts "Defence: "+list[1].to_s()
      if $player.hand == 0
        puts "You Don't Equip A Weapon."
      elsif
        puts "Weapon: "+$player.hand.name
      end
      puts "Floor: "+$floor.to_s
      puts "Area: "+$area
    elsif a=~ /^help/
      puts "w/a/s/d           Move the Player(@) & Attack."
      puts "l                 Show the Player(@)'s Status."
      puts "i                 Move the Player(@)'s Weapon to the Backpack"
      puts "k                 Show The Backpack"
      puts "o[backpack no.]   Equip A Weapon"
      puts "u[backpack no.]   Use A Potion"
      puts "help              Show This Help Page."
    else
       puts "Error:Invalid Command,Use \"help\" for Help."
    end
  end
  $map.each do |i|
    i.each do |j|
      if j.class == LtEnemy && j.hp <= 0
        j.destroy()
      end
    end
  end
  if $player.hp <= 0
    mapRend()
    puts "You Died!Game Over."
    print "Press Any Key to Exit."
    gets()
    exit()
  end
end
