class LtKnife < LtItem
  def initialize()
    a=[0,0,1,1,2,2,2,3,3,4]
    @r_lvl=a[Random.rand(10)]
  end
  def sign()
    return "weapon"
  end
  def name()
    if @r_lvl==0
      return "Broken Knife"
    elsif @r_lvl==1
      return "Rusted Knife"
    elsif @r_lvl==2
      return "Normal Knife"
    elsif @r_lvl==3
      return "Sharp Knife"
    elsif @r_lvl==4 
      return "Elite Knife"
    end
  end
  def sharp()
    if @r_lvl<3
      @r_lvl=@r_lvl+1
    end
  end
  def atk()
    if @r_lvl==0
      a=[0,0,0,1,1]
      return 2+a[Random.rand(5)]
    elsif @r_lvl==1
      a=[0,0,1,1,2]
      return 2+a[Random.rand(5)]
    elsif @r_lvl==2
      a=[0,0,1,1,2]
      return 3+a[Random.rand(5)]
    elsif @r_lvl==3
      a=[0,1,1,2,2]
      return 3+a[Random.rand(5)]
    elsif @r_lvl==4
      a=[0,2,2,2,1]
      return 4+a[Random.rand(5)]
    end
  end
end
class LtSword < LtItem
  def initialize()
    a=[0,1,1,2,2,2,2,3,3,4]
    @r_lvl=a[Random.rand(10)]
  end
  def sign()
    return "weapon"
  end
  def name()
    if @r_lvl==0
      return "Broken Sword"
    elsif @r_lvl==1
      return "Rusted Sword"
    elsif @r_lvl==2
      return "Normal Sword"
    elsif @r_lvl==3
      return "Sharp Sword"
    elsif @r_lvl==4 
      return "Elite Sword"
    end
  end
  def sharp()
    if @r_lvl<3
      @r_lvl=@r_lvl+1
    end
  end
  def atk()
    if @r_lvl==0
      a=[0,0,1,1,1]
      return 4+a[Random.rand(5)]
    elsif @r_lvl==1
      a=[0,0,1,1,2]
      return 4+a[Random.rand(5)]
    elsif @r_lvl==2
      a=[0,0,1,2,2]
      return 5+a[Random.rand(5)]
    elsif @r_lvl==3
      a=[0,1,2,2,2]
      return 5+a[Random.rand(5)]
    elsif @r_lvl==4
      a=[0,2,2,2,2]
      return 6+a[Random.rand(5)]
    end
  end
end
class LtAxe < LtItem
  def initialize()
    a=[0,1,1,1,2,2,2,2,3,4]
    @r_lvl=a[Random.rand(10)]
  end
  def sign()
    return "weapon"
  end
  def name()
    if @r_lvl==0
      return "Broken Axe"
    elsif @r_lvl==1
      return "Rusted Axe"
    elsif @r_lvl==2
      return "Normal Axe"
    elsif @r_lvl==3
      return "Sharp Axe"
    elsif @r_lvl==4 
      return "Elite Axe"
    end
  end
  def sharp()
    if @r_lvl<3
      @r_lvl=@r_lvl+1
    end
  end
  def atk()
    if @r_lvl==0
      a=[-2,0,0,2,3]
      return 3+a[Random.rand(5)]
    elsif @r_lvl==1
      a=[-1,0,2,3,2]
      return 3+a[Random.rand(5)]
    elsif @r_lvl==2
      a=[-1,0,3,2,3]
      return 4+a[Random.rand(5)]
    elsif @r_lvl==3
      a=[0,0,2,3,3]
      return 5+a[Random.rand(5)]
    elsif @r_lvl==4
      a=[0,2,3,3,3]
      return 6+a[Random.rand(5)]
    end
  end
end
class LtGlassSword < LtItem
  def name()
    return "[SP]Glass Sword"
  end
  def atk()
    a=Random.rand(2)
    if a==1
      return 15+Random.rand(5)
    else
      puts "The Glass Sword Breaks!"
      $player.hand=0
      return 15+Random.rand(5)
    end
  end
  def sign()
    return "weapon"
  end
  def sharp()
    puts "Unable to Sharp it."
  end
end
