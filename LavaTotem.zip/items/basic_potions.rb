class LtHealthPotion < LtItem
  def initialize ()
    @name="Health Potion"
  end
  def sign()
    return "potion"
  end 
  def use()
    $player.hp=$player.hp+20+Random.rand(10)
  end
  def name()
    @name
  end
end
class LtAtkPotion < LtItem
  def initialize ()
    @name="Attack Potion"
  end
  def sign()
    return "potion"
  end 
  def use()
    $player.atk=$player.atk+2+Random.rand(3)
  end
  def name()
    @name
  end
end