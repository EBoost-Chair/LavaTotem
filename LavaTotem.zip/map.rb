$map=[]
def mapGene()
  $area_m.areaSpawn()
  x=Random.rand(10)+10
  y=Random.rand(10)+10
  $map=Array.new(x){|i| i=Array.new(y)}
  x.times do |i|
    y.times do |j|
     ary=[0,0,0,0,4,5]
     $map[i][j]=ary[Random.rand(6)]
    end
  end
  e=Random.rand(3)+1
  e.times do |i|
    a=Random.rand(x-1)+1
    b=Random.rand(y-1)+1
    $map[a][b]=LtEnemy.new(a,b)
  end
  a=Random.rand(x-1)+1
  b=Random.rand(y-1)+1
  $map[a][b]=6
  p=Random.rand(x-1)+1
  q=Random.rand(y-1)+1
  $player.set_pos(p,q)
  x.times do |i|
    $map[i].push(4)
    $map[i][0]=4
  end
  $map[0]=Array.new(y+1,4)
  $map.push(Array.new(y+1,4))
  c=Random.rand(4)+1
  c.times do |i|
    b=Random.rand(2)
    if b==0
      a=Random.rand(x-1)
      $map[a+1][0]=8
      list=[0,5]
      $map[a+1][1]=list[Random.rand(2)]
    elsif b==1
      a=Random.rand(x-1)
      $map[a+1][-1]=8
      list=[0,5]
      $map[a+1][-2]=list[Random.rand(2)]
    end
  end
  $map[$player.x][$player.y]=0   
end
def mapRend()
  a=$map[$player.x][$player.y]
  $map[$player.x][$player.y]=9
  $map.each do |i|
    i.each do |j|
      if j==0
        print " "
      elsif j==8
        print "+"
      elsif j==9
        print "@"
      elsif j==4
        print "#"
      elsif j==5
        print "X"
      elsif j==6
        print "*"
      elsif j.class == LtEnemy
        print "A"
      end
    end
    puts
  end
  $map[$player.x][$player.y]=a
end
