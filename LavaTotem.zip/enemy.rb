class LtEnemy
  def x=(v)
    @x=v
  end
  def y=(v)
    @y=v
  end
  def x()
    @x
  end
  def y()
    @y
  end
  def atk()
    @atk
  end
  def hp()
    @hp
  end
  def hp=(v)
    @hp=v
  end
  def mtk=(v)
    @mtk=v
  end
  def mtk()
    @mtk
  end
  def destroy()
    puts "The "+@name+" Died!"
    $map[@x][@y]=0
  end
  def initialize(x,y)
    if $area=="Forest"
      a=Random.rand(3)
      if a==0
        @name="Rat"
        @atk_m="Bites"
        @atk=Random.rand(2)+1
        @hp=40+Random.rand(10)
      elsif a==1
        @name="Dwarf"
        @atk_m="Hits"
        @atk=Random.rand(4)+2
        @hp=60+Random.rand(10)
      elsif a==2
        @name="Thief"
        @atk_m="Hits"
        @atk=Random.rand(5)+1
        @hp=50+Random.rand(10)
      end
    elsif $area=="Wetland"
      a=Random.rand(3)
      if a==0
        @name="Big Slime"
        @atk_m="Attacks"
        @atk=Random.rand(2)+1
        @hp=40+Random.rand(10)
      elsif a==1
        @name="Witch"
        @atk_m="Hits"
        @atk=Random.rand(4)+2
        @hp=60+Random.rand(10)
      elsif a==2
        @name="Dark Elf"
        @atk_m="Bites"
        @atk=Random.rand(5)+1
        @hp=50+Random.rand(10)
      end
    elsif $area=="Grassy"
      a=Random.rand(3)
      if a==0
        @name="Slime"
        @atk_m="Attacks"
        @atk=Random.rand(2)+1
        @hp=40+Random.rand(10)
      elsif a==1
        @name="Goblin"
        @atk_m="Hits"
        @atk=Random.rand(4)+2
        @hp=60+Random.rand(10)
      elsif a==2
        @name="Wolf"
        @atk_m="Bites"
        @atk=Random.rand(5)+1
        @hp=50+Random.rand(10)
      end 
    elsif $area=="Icyland"
      a=Random.rand(3)
      if a==0
        @name="Snowman"
        @atk_m="Attacks"
        @atk=Random.rand(2)+1
        @hp=40+Random.rand(10)
      elsif a==1
        @name="Aurora Elf"
        @atk_m="Hits"
        @atk=Random.rand(4)+2
        @hp=60+Random.rand(10)
      elsif a==2
        @name="Iceman"
        @atk_m="Attacks"
        @atk=Random.rand(5)+1
        @hp=50+Random.rand(10)
      end
    elsif $area=="Desert"
      a=Random.rand(3)
      if a==0
        @name="Zombie"
        @atk_m="Attacks"
        @atk=Random.rand(2)+1
        @hp=40+Random.rand(10)
      elsif a==1
        @name="Desert Robber"
        @atk_m="Hits"
        @atk=Random.rand(4)+2
        @hp=60+Random.rand(10)
      elsif a==2
        @name="Desert Bug"
        @atk_m="Bites"
        @atk=Random.rand(5)+1
        @hp=50+Random.rand(10)
      end         
    end
    @mtk=0
    @x=x
    @y=y
  end
  def re()
    $map[@x][@y].mtk=0
  end
  def ltAtk()
    puts "The "+@name+" "+@atk_m+" You!"
    $player.hp=$player.hp-(self.atk*10+Random.rand(10)-$player.def).abs
  end
  def act()
    if self.x+1==$player.x && self.y==$player.y
      self.ltAtk()
    elsif self.x-1==$player.x && self.y==$player.y
      self.ltAtk()
    elsif self.y+1==$player.y && self.x==$player.x
      self.ltAtk()
    elsif self.y-1==$player.y && self.x==$player.x  
      self.ltAtk()
    else
      a=Random.rand(4)
      if a==0 && $map[@x-1][@y] == 0 
        if @x-1!=$player.x || @y != $player.y
          u=@x
          v=@y
          $map[u][v].x=$map[u][v].x-1
          tmp=$map[u][v]
          $map[u-1][v]=tmp
          $map[u][v]=0
        end
      elsif a==1 && $map[@x+1][@y] == 0
        if @x+1!=$player.x || @y != $player.y
          u=@x
          v=@y
          $map[u][v].x=$map[u][v].x+1
          tmp=$map[u][v]
          $map[u+1][v]=tmp
          $map[u][v]=0
        end
      elsif a==2 && $map[@x][@y-1] == 0
        if @x!=$player.x || @y-1 != $player.y
          u=@x
          v=@y
          $map[u][v].y=$map[u][v].y-1
          tmp=$map[u][v]
          $map[u][v-1]=tmp
          $map[u][v]=0
        end
      elsif a==3 && $map[@x][@y+1] == 0
        if @x!=$player.x || @y+1 != $player.y
          u=@x
          v=@y
          $map[u][v].y=$map[u][v].y+1
          tmp=$map[u][v]
          $map[u][v+1]=tmp
          $map[u][v]=0
        end
      end
    end
    @mtk=1
  end
end
